package softuni.exam.models.entity;

public enum ApartmentType {
    two_rooms,
    three_rooms,
    four_rooms
}
